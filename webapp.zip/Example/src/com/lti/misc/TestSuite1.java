package com.lti.misc;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({TestCa.class,TestCa2.class})
public class TestSuite1 {
}
