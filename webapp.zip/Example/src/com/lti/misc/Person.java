package com.lti.misc;

public abstract class Person {
public abstract void eats();
public abstract void sleeps();
}
