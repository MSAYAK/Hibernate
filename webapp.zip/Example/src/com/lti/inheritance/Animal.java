package com.lti.inheritance;

public interface Animal {
public void eat();
}
