package com.lti.inheritance;

public class Gadget {
protected String manufacturer;
protected  double price;
protected  int yrOfMfg;

public void turnOn()
{
	}
public void turnOff()
{ 
	
}

}
