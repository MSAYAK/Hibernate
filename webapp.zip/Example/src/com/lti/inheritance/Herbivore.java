package com.lti.inheritance;

public class Herbivore implements Animal {

	@Override
	public void eat() {
		System.out.println("Eats Plants");
		
	}

}
