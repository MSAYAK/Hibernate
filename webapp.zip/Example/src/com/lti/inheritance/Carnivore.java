package com.lti.inheritance;

public class Carnivore implements Animal {

	@Override
	public void eat() {
		System.out.println("Eats other Animals");
		
	}

}
