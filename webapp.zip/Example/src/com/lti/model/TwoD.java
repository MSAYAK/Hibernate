package com.lti.model;

public abstract class TwoD extends Shape {

}
