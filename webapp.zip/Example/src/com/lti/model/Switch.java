package com.lti.model;

public class Switch {
public static void main(String args[])
{
	int x=5;

	switch(1)
	{
	case 1 : x=x+1;
	case 2: x=x+2;
	default: System.out.println(x);
	}
}
}
