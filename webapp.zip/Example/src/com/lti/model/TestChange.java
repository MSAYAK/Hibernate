package com.lti.model;

public class TestChange {
	public static void main(String args[])
	{
		Changeable ch1=new EquilateralTriangle( );
		ch1.color();
		ch1.shadow();
		ch1.outline( );
	}

}
