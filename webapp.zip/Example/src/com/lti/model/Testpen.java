package com.lti.model;

public class Testpen {
public static void main(String args[])
{
	Testpen t1=new Testpen( );
	t1.greet( );

}
public void greet()
{
	System.out.println("hello world!!");
}
}

