package com.lti.model;

public class EquilateralTriangle extends Triangle implements Changeable{
public void draw()
{
	System.out.println("Drawing Equilateral Triangle");
}
public void color() {
	System.out.println("equi color");
}

public void outline() {
	System.out.println("equi outline");
	
}

public void shadow() {
	System.out.println("equi shadow");
	
}
}
