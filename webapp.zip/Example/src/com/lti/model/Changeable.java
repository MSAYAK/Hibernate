package com.lti.model;

public interface Changeable {
public void  color( );
public void  outline( );
public void  shadow( );

}
