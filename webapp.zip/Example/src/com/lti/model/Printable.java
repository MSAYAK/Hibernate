package com.lti.model;

public interface Printable {
	
	public static  void  print()
	{
	System.out.println("print");
	}
	
}
