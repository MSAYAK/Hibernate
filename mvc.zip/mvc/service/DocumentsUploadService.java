package com.lnt.mvc.service;

import java.util.List;

import com.lnt.mvc.model.ScholarshipApplicationForm;

public interface DocumentsUploadService {
	
	
	public void save(ScholarshipApplicationForm scholarshipform);
	
	 public List<ScholarshipApplicationForm>list(); 
	 public void remove(Integer
	 id); 
	 public ScholarshipApplicationForm get(Integer id);
	
	

}
