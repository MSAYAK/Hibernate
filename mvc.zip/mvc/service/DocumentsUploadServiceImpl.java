package com.lnt.mvc.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.mvc.dao.DocumentsUploadDao;
import com.lnt.mvc.model.ScholarshipApplicationForm;
@Service
public class DocumentsUploadServiceImpl implements DocumentsUploadService {
	@Autowired
	private DocumentsUploadDao documentsUploadDao;
	
	
	

	public void setDocumentsUploadDao(DocumentsUploadDao documentsUploadDao) {
		this.documentsUploadDao = documentsUploadDao;
	}

	@Override
	@Transactional
	public void save(ScholarshipApplicationForm scholarshipform) {
		 
		this.documentsUploadDao.save(scholarshipform);
	}


	 @Override
	 public List<ScholarshipApplicationForm> list() {
	
	return this.documentsUploadDao.list(); }
	
	  @Override
	  public void remove(Integer id) {
	this.documentsUploadDao.remove(id);
	  }

	
	
	  @Override public ScholarshipApplicationForm get(Integer id) {
	
	  return this.documentsUploadDao.get(id); }
	
}
