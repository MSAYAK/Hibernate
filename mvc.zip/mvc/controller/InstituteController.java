package com.lnt.mvc.controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lnt.mvc.model.Registration;
import com.lnt.mvc.model.ScholarshipApplicationForm;
import com.lnt.mvc.model.StudentRegistration;
import com.lnt.mvc.service.InstituteService;

@Controller
public class InstituteController {
@Autowired
	private InstituteService instituteService;

public void setInstituteService(InstituteService instituteService) {
	this.instituteService = instituteService;
}
	
	



/*@RequestMapping(value="/presentstatus1", 
method = RequestMethod.POST)
public String addStudent(@ModelAttribute("scholarship") 
@Valid ScholarshipApplicationForm scholarshipApplicationForm, 
BindingResult result, 
Model model,HttpSession session) {
scholarshipApplicationForm.setRequestStatus("PENDING");
StudentRegistration r=(StudentRegistration)session.getAttribute("");
this.iFarmerService.addCrop(potentialcrop);
return "applicationstatus";

}*/

@RequestMapping(value="/institutestatus")
public String ministerlogin(Model model) {
	System.out.println("hello guyzz");
	List<ScholarshipApplicationForm> applicationform = this.instituteService.listapplications();
model.addAttribute("studentlists0",applicationform);
return "institutestatus";
}





/*@RequestMapping(value="/sellcrop")
public String sellCrop(Model model,HttpSession session) {
model.addAttribute("potentialcrop",new ScholarshipApplicationForm());
return "";
}*/

/*@RequestMapping(value="/signout",method= RequestMethod.GET)
public String signout( Model model ,HttpSession session)
{
session.invalidate();
model.addAttribute("farmer",new ScholarshipApplicationForm());
return "FarmerLogin";
}
*/

@RequestMapping(value="/logoutinstitute",method= RequestMethod.GET)
public String institutesignout( Model model)
{
model.addAttribute("institute",new Registration());
return "redirect:institutelogin";
}

 


	
	  @RequestMapping("/accept/{studentId}") public String acceptStudent(
	 
	 @PathVariable("studentId") int studentId,Model model) {
		  
	  this.instituteService.acceptApplicaton(studentId);
	  
	  List<ScholarshipApplicationForm>
	  applicationForms=this.instituteService.listapplications();
	  model.addAttribute("ApplicationForms", applicationForms); return
	  "institute dashboard"; }
	 
	  @RequestMapping("/reject/{studentId}") public String rejectStudent(
	 
	  @PathVariable("studentId") int studentId,Model model) {
	  this.instituteService.rejectApplication(studentId);
	  List<ScholarshipApplicationForm>applicationForms=
	 this.instituteService.listapplications();
	 model.addAttribute("ApplicationForms",applicationForms); return
	  "institute dashboard"; }
	 

 


}


