package com.lnt.mvc.model;

public class NodalOfficer {

private String officerusername;
private String officerpassword;
public String getOfficerusername() {
return officerusername;
}
public void setOfficerusername(String officerusername) {
this.officerusername = officerusername;
}
public String getOfficerpassword() {
return officerpassword;
}
public void setOfficerpassword(String officerpassword) {
this.officerpassword = officerpassword;
}
public NodalOfficer(String officerusername, String officerpassword) {
super();
this.officerusername = officerusername;
this.officerpassword = officerpassword;
}
public NodalOfficer() {
super();
}
@Override
public String toString() {
return "NodalOfficer [officerusername=" + officerusername + ", officerpassword=" + officerpassword + "]";
}






}

